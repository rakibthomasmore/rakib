﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace booking
{
    /// <summary>
    /// Interaction logic for Log_in.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        private readonly DatabaseHelper _dbHelper = new DatabaseHelper();

        public LoginWindow()
        {
            InitializeComponent();
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            var username = UsernameTextBox.Text;
            var password = PasswordBox.Password;

            // Assuming DatabaseHelper contains a method for validating user credentials
            DatabaseHelper db = new DatabaseHelper();
            bool isValidUser = await db.ValidateUserAsync(username, password);

            if (isValidUser)
            {
                MessageBox.Show("Login successful!");

                // After successful login validation
                UserSession.CurrentUserName =username;

                // Close the current Login Window
                //this.Close();

                // Open the Home Page Window
                HomePage homePage = new HomePage();
                homePage.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid username or password. Please try again.");
            }

        }
        public static class UserSession
        {
            public static string CurrentUserName { get; set; }
            // Add other session-related properties here
        }


        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            var signUpWindow = new SignUpWindow();
            signUpWindow.ShowDialog();
        }
        

        private void UsernameTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            UsernameWatermark.Visibility = Visibility.Collapsed;
        }

        private void UsernameTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(UsernameTextBox.Text))
            {
                UsernameWatermark.Visibility = Visibility.Visible;
            }
        }

        private void PasswordBox_GotFocus(object sender, RoutedEventArgs e)
        {
            PasswordWatermark.Visibility = Visibility.Collapsed;
        }

        private void PasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(PasswordBox.Password))
            {
                PasswordWatermark.Visibility = Visibility.Visible;
            }
        }

        // ... Other event handlers and methods ...
    }

}
