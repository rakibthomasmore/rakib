﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace booking
{
    public class DatabaseHelper
    {
        private string connectionString = "server=localhost;database=booking;uid=root;pwd=@Green420@;";

        public async Task<bool> CreateUserAsync(string username, string email, string password)
        {
            // Hash the password before storing it.
            string hashedPassword = HashPassword(password);
            try
            {


                using (var connection = new MySqlConnection(connectionString))
                {
                    await connection.OpenAsync();
                    string query = "INSERT INTO Users (Username, Email, PasswordHash) VALUES (@Username, @Email ,@PasswordHash)";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@PasswordHash", hashedPassword);

                        var result = await command.ExecuteNonQueryAsync();
                        return result > 0;
                    }
                }
            }
            catch(MySqlException ex)
            {
                if (ex.Number == 1062) // MySQL error code for a duplicate entry
                {
                    // Log the exception or inform the user
                    // For example: Log.Error(ex, "Attempted to insert duplicate email.");
                    return false; // Return false to indicate that the user was not created due to duplicate email
                }
                else
                {
                    throw; // Rethrow the exception if it's not related to a duplicate entry
                }

            }
         }

        public async Task<bool> ValidateUserAsync(string username, string password)
        {
            
            string hashedPassword = HashPassword(password);

            using (var connection = new MySqlConnection(connectionString))
            {
                await connection.OpenAsync();
                string query = "SELECT COUNT(1) FROM Users WHERE Username = @Username AND PasswordHash = @PasswordHash";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@PasswordHash", hashedPassword);

                    var result = await command.ExecuteScalarAsync();
                    return Convert.ToInt32(result) > 0;
                }
            }
        }


        public async Task<List<Booking>> GetBookingsAsync(string username)
        {
            List<Booking> bookings = new List<Booking>();
            string query = $"SELECT * FROM Bookings WHERE Username = @Username"; // Adjust query as per your schema

            using (var connection = new MySqlConnection(connectionString))
            {
                await connection.OpenAsync();
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            bookings.Add(new Booking
                            {
                                // Initialize booking from reader
                            });
                        }
                    }
                }
            }

            return bookings;
        }


        private string HashPassword(string password)
        {
            // Implement a secure password hashing mechanism.
            // Placeholder for hashing logic:
            return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(password));
        }
    }

}
