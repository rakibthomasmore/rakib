﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace booking
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Window
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private void BookNow_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the booking page
            var bookingPage = new MainWindow();
            bookingPage.Show();
        }

        private void ViewBookings_Click(object sender, RoutedEventArgs e)
        {
            var viewBookingsWindow = new ViewBookingsWindow();
            viewBookingsWindow.Show();
        }


        private void Services_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the services page
        }
        private void AboutUs_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the about us page or perform related actions
            // For example, you might display an about dialog like so:
            // AboutDialog aboutDialog = new AboutDialog();
            // aboutDialog.ShowDialog();
        }

        private void Contact_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the contact page or perform related actions
            // For example, you might open a new contact form window like so:
            // ContactForm contactForm = new ContactForm();
            // contactForm.ShowDialog();
        }

        // Add more event handlers for additional buttons
    }
}
