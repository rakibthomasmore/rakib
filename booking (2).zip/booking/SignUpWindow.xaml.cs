﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace booking
{
    /// <summary>
    /// Interaction logic for SignUpWindow.xaml
    /// </summary>
    public partial class SignUpWindow : Window
    {
        private readonly DatabaseHelper _dbHelper = new DatabaseHelper();

        public SignUpWindow()
        {
            InitializeComponent();
        }

        private async void CreateAccountButton_Click(object sender, RoutedEventArgs e)
        {
            var username = UsernameTextBox.Text;
            var email = EmailTextBox.Text;
            var password = PasswordBox.Password;
            var confirmPassword = ConfirmPasswordBox.Password;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email)|| string.IsNullOrEmpty(password) || password != confirmPassword)
            {
                MessageBox.Show("Please fill in all fields correctly.");
                return;
            }

            // Assuming CreateUserAsync attempts to create a new user and returns true if successful
            bool success = await CreateUserAsync(username,email, password);

            if (success)
            {
                MessageBox.Show("Account created successfully. Please log in.");

                // Open the Login Window
                LoginWindow loginWindow = new LoginWindow();
                loginWindow.Show();

                // Close the current Sign Up Window
                Close();
            }
            else
            {
                MessageBox.Show("Failed to create account. Please try again.");
            }
        }

        // Implementation assumes existence of CreateUserAsync method
        private async Task<bool> CreateUserAsync(string username,string email, string password)
        {
            // Insert your user creation logic here. E.g.:
            var dbHelper = new DatabaseHelper(); // Assuming DatabaseHelper has the method to create user
            return await dbHelper.CreateUserAsync(username, email,password);
        }




        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            UsernameWatermark.Visibility = Visibility.Collapsed;
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(UsernameTextBox.Text))
            {
                UsernameWatermark.Visibility = Visibility.Visible;
            }
        }

        private void PasswordBox_GotFocus(object sender, RoutedEventArgs e)
        {
            // Replace with the corresponding PasswordBox and TextBlock
            PasswordWatermark.Visibility = Visibility.Collapsed;
        }

        private void PasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            // Replace with the corresponding PasswordBox and TextBlock
            if (string.IsNullOrEmpty(PasswordBox.Password))
            {
                PasswordWatermark.Visibility = Visibility.Visible;
            }
        }

        // Confirm password focus/lost focus methods
        // ...

        
    }
}



